﻿/*************************************************************************************
 *
 * 创建人员:  zrq 
 * 创建时间:  2022/1/3 18:01:26
 * 文件描述:  
 * 
*************************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RQ.Test.RevtDotNet.测试扩展数据
{
    /// <summary>
    /// 测试扩展数据界面Model
    /// </summary>
    public class TestStorageWinModel
    {
        public int TestElementId { get; set; } = 0;
    }
}